# bug-tracking-app
A web application which provides bug management for an application
