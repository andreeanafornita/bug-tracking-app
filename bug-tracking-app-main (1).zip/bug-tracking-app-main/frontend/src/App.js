import './App.css';
import axios from "axios";
import { useEffect, useState } from "react";



function App() {

  // useEffect(()=>{
  //   axios.get("")
  // }, [])

  return (
    <div>

    </div>
  );
}

export default App;
